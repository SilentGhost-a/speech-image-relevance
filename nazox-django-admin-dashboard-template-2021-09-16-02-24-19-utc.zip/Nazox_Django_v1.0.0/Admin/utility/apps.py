from django.apps import AppConfig


class UtilityConfig(AppConfig):
    name = 'utility'
